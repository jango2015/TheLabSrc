/**
 * Created by 潘学平 on 2016/8/16.
 */
/*所有网点界面事件*/
$(function(){
    $("#network .title .sx").click(function(){
        $("#network .location_screening").css("display","block");
        $("#network .mask").css("display","block");
    });
    $("#network .location_screening .list").click(function(){
        $("#network .location_screening").css("display","none");
        $("#network .mask").css("display","none");
        $(this).children("input").attr("checked","true");
    });
    $("#network .mask").click(function(){
        $("#network .location_screening").css("display","none");
        $("#network .mask").css("display","none");
    });
    $("#network ul li .right .icon-dadianhuatianchong").click(function(){
        $("#network .phone").css("display","block");
        $("#network .phone .no").click(function(){
            $("#network .phone").css("display","none");
        });
        $("#network .phone .yes").click(function(){
            var date=$("#network .phone span").text();
            window.location.href='tel://'+date;
        });
    });
    $("#network ul li .right .icon-didian-copy").click(function(){
        $("#network .map").css("display","block");
        $("#network .map .no").click(function(){
            $("#network .map").css("display","none");
        });
        $("#network .map .yes").click(function(){
            window.location.href='http://l.map.qq.com/12912071940?m';
        });
    });
});
/*商品列表界面事件*/
$(function(){
    /*头部标签页切换*/
    $("#list .tabs div").click(function(){
        $(this).addClass("active").siblings().removeClass("active");
        var index=$(this).index();
        $("#list .tab").eq(index).css("display","block");
        $("#list .tab").eq(index).siblings().css("display","none");
    });
    /*筛选弹出层*/
    $("#list .content .filter").click(function(){
        $("#list .content .filter_ct").show();
    });
    $("#list .content .filter_ct").on("click","li",function(){
        $(this).addClass("active").siblings().removeClass("active");
        $("#list .content .filter_ct").hide();
    });
    /*购物车弹出 隐藏*/
    $("#list nav .shop").click(function(){
        $("#list .shop_order").toggle();
    });
    /*购物车商品加减*/
    $("#list .shop_order").on("click",".plus",function(){
        var num=$(this).siblings("span").text();
        num++;
        $(this).siblings("span").text(num);
    });
    $("#list .shop_order").on("click",".minus",function(){
        var num=$(this).siblings("span").text();
        num--;
        if(num<1){
            $(this).parents("li").remove();
        }
        $(this).siblings("span").text(num);
    });
    /*购物车清空*/
    $("#list .shop_order .sc").click(function(){
        $("#list .shop_order ul li").remove();
    });
});
/*订单详情界面轮播*/
$(function(){
    setInterval(function(){

    },1000);
    $("#order_details .information .plus").click(function(){
        var num=Number($(this).siblings(".number").text());
        num++;
        $(this).siblings(".number").text(num);
    });
    $("#order_details .information .minus").click(function(){
        var num=Number($(this).siblings(".number").text());
        num--;
        if(num<1){
            num=1;
        }
        $(this).siblings(".number").text(num);
    });
});
/*我的订单界面事件*/
$(function(){
    $("#member_order .head .one").click(function(){
        $(this).addClass("active");
        $("#member_order .head .two").removeClass("active");
        $("#member_order .content .order_unfinished").css("display","block");
        $("#member_order .content .order_completed").css("display","none");
    });
    $("#member_order .head .two").click(function(){
        $(this).addClass("active");
        $("#member_order .head .one").removeClass("active");
        $("#member_order .content .order_completed").css("display","block");
        $("#member_order .content .order_unfinished").css("display","none");
    });
    /*删除订单*/
    $("#member_order").on("click",".delete_order",function(event){
        var a=$(this);
        $("#member_order .del").css("display","block");
        $("#member_order .del .no").click(function(){
            $("#member_order .del").css("display","none");
        });
        $("#member_order .del .yes").click(function(){
            var i=a.parents("li").children(".box").length;
            if(i>1){
                a.parent().parent().remove();
            }else{
                a.parents("li").remove();
            }
            $("#member_order .del").css("display","none");
        });
    });
});
/*我的优惠券界面事件*/
$(function(){
    $("#coupon").on("click","li",function(){
        $(this).addClass("active").siblings().removeClass();
    });
});
/*订单详情界面事件*/
$(function(){
    $("#member_details .jfdy div").click(function(){
        if($(this).attr("class").indexOf("on_off")==-1){
            $(this).removeClass("off_on");
            $(this).addClass("on_off");
        }else{
            $(this).removeClass("on_off");
            $(this).addClass("off_on");
        }
    });
});
/*个人资料界面事件*/
$(function(){
    $(".personal_data input[type=date]").blur(function(){
        var text=$(this).val();
        var month=Number(text.substr(5,2));
        var date=text.substr(8,2);
        if(month == 1 && date >=20 || month == 2 && date <=18){
            $(".personal_data .constellation").text("水瓶座")
        }
        if(month == 2 && date >=19 || month == 3 && date <=20){
            $(".personal_data .constellation").text("双鱼座")
        }
        if(month == 3 && date >=21 || month == 4 && date <=19){
            $(".personal_data .constellation").text("白羊座")
        }
        if(month == 4 && date >=20 || month == 5 && date <=20){
            $(".personal_data .constellation").text("金牛座")
        }
        if(month == 5 && date >=21 || month == 6 && date <=21){
            $(".personal_data .constellation").text("双子座")
        }
        if(month == 6 && date >=22 || month == 7 && date <=22){
            $(".personal_data .constellation").text("巨蟹座")
        }
        if(month == 7 && date >=23 || month == 8 && date <=22){
            $(".personal_data .constellation").text("狮子座")
        }
        if(month == 8 && date >=23 || month == 9 && date <=22){
            $(".personal_data .constellation").text("室女座")
        }
        if(month == 9 && date >=23 || month == 10 && date <=22){
            $(".personal_data .constellation").text("天秤座")
        }
        if(month == 10 && date >=23 || month == 11 && date <=21){
            $(".personal_data .constellation").text("天蝎座")
        }
        if(month == 11 && date >=22 || month == 12 && date <=21){
            $(".personal_data .constellation").text("人马座")
        }
        if(month == 12 && date >=22 || month == 1 && date <=19){
            $(".personal_data .constellation").text("摩羯座")
        }
    })
});